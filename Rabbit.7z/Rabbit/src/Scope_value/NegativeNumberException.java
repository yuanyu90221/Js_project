/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Scope_value;

import rabbit.*;

/**
 *
 * @author asus-nb
 */
public class NegativeNumberException extends Exception {
    private int check_month;
    public NegativeNumberException(int ckeck_month){
        super();
        this.setCheck_month(check_month);
    }
    public int getCheck_month() {
        return check_month;
    }

    public void setCheck_month(int check_month) {
        this.check_month = check_month;
    }
    
}
