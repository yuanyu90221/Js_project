/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Scope_value;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.*;

/**
 *
 * @author asus-nb
 */
public class Scope_value {

    public static void main(String[] args) {
        int scope = 0;
        BufferedReader vf = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.print("Please enter your scope: ");
            scope = Integer.parseInt(vf.readLine());
            classify_grade(scope);
        } catch (IOException | NumberFormatException e) {

        }catch(rabbit.NegativeNumberException e){
            System.out.println("Your input value range is wrong");
        }
    }

    public static void classify_grade(int scope) throws rabbit.NegativeNumberException {
        int raw_data = scope;
        if(raw_data < 0) throw new rabbit.NegativeNumberException(scope); 
        int grade_level = scope / 10;
        switch (grade_level) {
            case 10:
                System.out.println("Your grade level is :A+");
                break;
            case 9:
                System.out.println("Your grade level is :A");
                break;
            case 8:
                System.out.println("Your grade level is :B");
                break;
            case 7:
                System.out.println("Your grade level is :C");
                break;
            case 6:
                System.out.println("Your grade level is :D");
                break;
            case 5:
            case 4:
            case 3:
            case 2:
            case 1:
            case 0:// 0~9
                System.out.println("Your grade level is :F");
                break;
        }
    }
}
