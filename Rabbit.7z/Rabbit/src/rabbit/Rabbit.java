/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rabbit;

import java.lang.Exception;
import java.io.*;
import java.util.Date;
import Scope_value.*;

/**
 *
 * @author asus-nb
 */
public class Rabbit {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws NegativeNumberException {

        long pair = 0;
        int months = 0;
        long pair_1 = 0;

        BufferedReader vf = new BufferedReader(new InputStreamReader(System.in));
        try {
            System.out.println("遞迴算法:");
            System.out.print("請輸入幾個月:");
            months = Integer.parseInt(vf.readLine());
            pair = getRabbits(months);
            System.out.println("總共" + months + "個月 共　" + pair + "　對兔子在島上");
            System.out.println("==============================================");
            System.out.println("代數算法:");
            System.out.print("請輸入幾個月:");
            months = Integer.parseInt(vf.readLine());
            pair_1 = getRabbit(months);
            System.out.print("總共" + months + "個月");
            System.out.printf("　共%d　對兔子在島上\n", pair_1);
            // Scope_value.classify_grade((int)pair_1);
        } catch (NegativeNumberException e) {
            System.out.println("Error input month:" + e.getCheck_month());
            System.out.println("Month must be positive");
        } catch (IOException | NumberFormatException e) {
            if (e instanceof IOException) {
                System.out.println("鍵盤讀取錯誤");
            } else {
                System.out.println("輸入格式錯誤");
            }
        }
    }
    /*
     method name: getRabbits
     type        :static
     input       :int months
     output      :long pairs
     ---------------------------
     recursive versions:
     getRabbit(n) =(n>1)?(getRabbits(n-1)+getRabbits(n-2)):1;
     */

    public static long getRabbits(int months) throws NegativeNumberException {
        long pair = 0;
        if (months < 0) {
            throw new NegativeNumberException(months);
        }
        return (months > 1) ? (getRabbits(months - 1) + getRabbits(months - 2)) : 1;
    }
    /*
     method name: getRabbit
     type        :static
     input       :int months
     output      :double pairs
     ---------------------------
     Iterative versions:
     getRabbit(n) = 1    if n <=1
     result;
     temp1 = 1;
     temp2 = 1;
     for(i=1;i<=n;i++)
     {
     result = temp1+temp2;
     temp1 = temp2;
     temp2 = result;
     }
     */

    public static long getRabbit(int months) throws NegativeNumberException {
        long pair = 0;
        long first = 1, second = 1;
        if (months < 0) {
            throw new NegativeNumberException(months);
        }
        if (months <= 1) {
            return 1;
        } else {
            for (int i = 2; i <= months; i++) {
                pair = first + second;
                first = second;
                second = pair;
            }
            return pair;
        }
    }
}
