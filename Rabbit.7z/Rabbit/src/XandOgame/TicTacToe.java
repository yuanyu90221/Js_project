/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package XandOgame;
import javax.swing.*;
import java.awt.EventQueue;
import java.awt.*;
import java.awt.event.*;
/**
 *
 * @author asus-nb
 */
public class TicTacToe extends JFrame{
    
    private static final long serialVersionID=1L;//定義版號
    private JPanel contentPane;
    private static JTable table;
    public static void main(String[] args){
        EventQueue.invokeLater(new Runnable(){
           public void run(){//Thread 執行內容
             
              try{
                  //Generate TicTacToe object
                  TicTacToe frame = new TicTacToe();
                  frame.setVisible(true);
                  
              }catch(Exception e){//process the exception that probably happen
                  e.printStackTrace();
              }  
              
           } //Thread end 
          }
        );
    }
    
    private int count = 0;
    private int[][] situation;
    
    private void setTable(){
        final Object[][] tableItems = new Object[][]{
            {null,null,null},
            {null,null,null},
            {null,null,null}
        };
        situation = new int[3][3];
        table = new JTable();
        table.setGridColor(new Color(255,0,0));
        
        MouseAdapter mouseListener = new MouseAdapter(){
         // check if the current player wins
           private boolean checkWhetherTheCurrentPlayerWin(){
              System.out.println("Count = "+count);
              if(count<=3)
                  return false;
              int player =(count%2==0)?1:2;
              //check the two oblique line
              if(situation[1][1]==player){
                  if(situation[0][0]==player&&situation[2][2]==player)
                     return true;
                  if(situation[0][2]==player &&situation[2][0]==player)
                     return true;
              }
              //check rows
              for(int row = 0; row <3;row++)
              {
                  if(situation[row][0]==player&&situation[row][1]==player&&situation[row][2]==player){
                      return true;
                  }
              }
              //check columns
              for(int columns=0;columns < 3;columns++)
              {
                 if(situation[0][columns]==player&&situation[1][columns]==player&&situation[2][columns]==player){
                      return true;
                  } 
              }
              return false;
           }
        };
    }
}
